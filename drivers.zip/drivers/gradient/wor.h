#ifndef WOR_H
#define WOR_H

void wor_start(uint8_t is_sink);
void wor_stop(uint8_t is_sink);

#endif